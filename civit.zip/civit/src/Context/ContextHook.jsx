import { createContext } from "react";

export const ContextHook  = createContext();